#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sun Apr  8 02:18:20 2018
@author: lixi
File 2: download data from RoomB.py
"""
import pickle
#import matplotlib
#matplotlib.use('TkAgg')
###############################################################################
                           ## Open File ##
###############################################################################
#pkl_file = open('data-baseline.pkl', 'rb')
#pkl_file = open('data-30min.pkl', 'rb')
#pkl_file = open('data-05DHF.pkl', 'rb')
#pkl_file = open('data-30minseed2.pkl', 'rb')
#pkl_file = open('data-30minslow.pkl', 'rb')
#pkl_file = open('data.pkl', 'rb')                 
N = 2
opfile = 'RB2i_data_2_3620'
pkl_file = open(opfile, 'rb')     
                      
###############################################################################
                           ## Unpickle Data ##
###############################################################################
D_time = pickle.load(pkl_file)  # time[s]
D_RmT = pickle.load(pkl_file)   # RmT [F]
D_odL = pickle.load(pkl_file)   # odL [lux]
D_DLH = pickle.load(pkl_file)   # Daylight harvest [lux]

### Energy Cal
D_TE_L = pickle.load(pkl_file)   # second-level energy [kWh]
D_TCE_L = pickle.load(pkl_file)  # cumulative energy [kWh]
D_TE_AC = pickle.load(pkl_file)  # second-level energy [kWh]
D_TCE_AC = pickle.load(pkl_file) # cumulative energy [kWh]
D_TE = pickle.load(pkl_file)     # second-level energy [kWh]
D_TCE = pickle.load(pkl_file)    # cumulative energy [kWh]

### Heat tranfers
D_HTdl = pickle.load(pkl_file) # heat transfers [W]
D_HTaf = pickle.load(pkl_file) # heat transfers [W]
D_HTcd = pickle.load(pkl_file) # heat transfers [W]
D_HTac = pickle.load(pkl_file) # heat transfers [W]

### Lights
D_MoSen0 = pickle.load(pkl_file)  # Motion_detected?
D_PwrOn0 = pickle.load(pkl_file)  # Power_on?
D_MoSen1 = pickle.load(pkl_file)  # Motion_detected?
D_PwrOn1 = pickle.load(pkl_file)  # Power_on?
D_LM0 = pickle.load(pkl_file) # Light lumen [lux]
D_DF0 = pickle.load(pkl_file) # Light dimming factor
D_LM1 = pickle.load(pkl_file) # Light lumen [lux]
D_DF1 = pickle.load(pkl_file) # Light dimming factor

D_LCmft, D_TCmft ={},{}
### Occupants
for p in range(N):
    D_LCmft[p] = pickle.load(pkl_file) # Occupant lumen comfort
    D_TCmft[p] = pickle.load(pkl_file) # Occupant thermal comfort

###############################################################################
                           ## Close File ##
###############################################################################
pkl_file.close()
print 'download completed'