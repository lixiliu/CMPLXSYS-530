#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sun Apr  8 02:18:20 2018
@author: lixi
File 3: plot data from RoomB.py after downloadB.py
"""
#import matplotlib
#matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
# import pprint, pprint.pprint(data) -> prints data in column style
# print data -> prints data in row style

###############################################################################
                           ## Prints ##
###############################################################################
'''
D_time = pickle.load(pkl_file)  # time[s]
D_RmT = pickle.load(pkl_file)   # RmT [F]
D_odL = pickle.load(pkl_file)   # odL [lux]
D_DLH = pickle.load(pkl_file)   # Daylight harvest [lux]

### Energy Cal
D_TE_L = pickle.load(pkl_file)   # second-level energy [kWh]
D_TCE_L = pickle.load(pkl_file)  # cumulative energy [kWh]
D_TE_AC = pickle.load(pkl_file)  # second-level energy [kWh]
D_TCE_AC = pickle.load(pkl_file) # cumulative energy [kWh]
D_TE = pickle.load(pkl_file)     # second-level energy [kWh]
D_TCE = pickle.load(pkl_file)    # cumulative energy [kWh]

### Heat tranfers
D_HTdl = pickle.load(pkl_file) # heat transfers [W]
D_HTaf = pickle.load(pkl_file) # heat transfers [W]
D_HTcd = pickle.load(pkl_file) # heat transfers [W]
D_HTac = pickle.load(pkl_file) # heat transfers [W]

### Lights
D_MoSen0 = pickle.load(pkl_file)  # Motion_detected?
D_PwrOn0 = pickle.load(pkl_file)  # Power_on?
D_MoSen1 = pickle.load(pkl_file)  # Motion_detected?
D_PwrOn1 = pickle.load(pkl_file)  # Power_on?
D_LM0 = pickle.load(pkl_file) # Light lumen [lux]
D_DF0 = pickle.load(pkl_file) # Light dimming factor
D_LM1 = pickle.load(pkl_file) # Light lumen [lux]
D_DF1 = pickle.load(pkl_file) # Light dimming factor

### Occupants
for p in range(N):
    D_LCmft[p] = pickle.load(pkl_file) # Occupant lumen comfort
    D_TCmft[p] = pickle.load(pkl_file) # Occupant thermal comfort

# for Data-30min
D_TE_L2, D_TCE_L2, D_TE2, D_TCE2, TCEL = [],[],[],[],0
for i in range(len(D_TE_L)):
    TCEL += D_TE_L[i]*D_PwrOn[i]
    D_TE_L2.append(D_TE_L[i]*D_PwrOn[i])
    D_TE2.append(D_TE_L[i]*D_PwrOn[i]+D_TE_AC[i])
    D_TCE_L2.append(TCEL)
    D_TCE2.append(TCEL + D_TCE_AC[i])
    
plt.figure(12)
plt.plot(D_time,D_TCE_L2, label='Luminaire')
plt.plot(D_time,D_TCE_AC, label='AC')
plt.plot(D_time,D_TCE2, label='Total')
plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
plt.title('Cumulative Energy [KWh]')
    
'''
###############################################################################
                           ## Plots ##
###############################################################################

plt.figure(1)
plt.plot(D_time, D_odL, color = 'red', label='Available')
plt.plot(D_time, D_DLH, color = 'orange', label='Harvested')
plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
plt.title('Daylight Level [lux]')
plt.xlabel('Time Horizon (s)')

plt.figure(2)
plt.plot(D_time,D_RmT)
plt.title('Room Temperature (F)')
plt.xlabel('Time Horizon (s)')

plt.figure(3)
for p in range(N):
    plt.plot(D_time, D_LCmft[p], label='P%s LC' %str(p+1))
    plt.plot(D_time, D_TCmft[p], linestyle='--', label='P%s TC' %str(p+1))
plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
plt.title('Lumen (LC) and Thermal Comfort (TC)')
plt.xlabel('Time Horizon (s)')

plt.figure(4, figsize=(7,7))
plt.subplot(211)
plt.plot(D_time, D_MoSen0, color = 'violet', label='L1')
plt.plot(D_time, D_MoSen0, color = 'red', label='L2')
plt.legend(bbox_to_anchor=(0, 1.25, 1, .102), loc=3, ncol=2, mode="expand", borderaxespad=0.)
plt.title('Motion Sensor Output: Motion Detected?')
plt.xlabel('Time Horizon (s)')
plt.subplot(212)
plt.plot(D_time, D_PwrOn0, color = 'violet', label='L1')
plt.plot(D_time, D_PwrOn1, color = 'red', label='L2')
plt.title('Motion Sensor Command: Power On?')
plt.xlabel('Time Horizon (s)')
plt.tight_layout()

plt.figure(5, figsize=(7,7))
plt.subplot(211)
plt.plot(D_time, D_LM0, color = 'violet', label='L1')
plt.plot(D_time, D_LM1, color = 'red', label='L2')
plt.legend(bbox_to_anchor=(0, 1.25, 1, .102), loc=3, ncol=2, mode="expand", borderaxespad=0.)
plt.title('Luminaire Lumen Output [lux]')
plt.xlabel('Time Horizon (s)')
plt.subplot(212)
plt.plot(D_time, D_DF0, color = 'violet', label='L1')
plt.plot(D_time, D_DF1, color = 'red', label='L2')
plt.title('Luminaire Dimming Factors')
plt.xlabel('Time Horizon (s)')
plt.tight_layout()

plt.figure(6)
plt.plot(D_time, D_HTdl, color = 'orange', label='Daylight')
plt.plot(D_time, D_HTaf, color = 'green', label='Ventilation')
plt.plot(D_time, D_HTcd, color = 'red', label='Conduction')
plt.plot(D_time, D_HTac, color = 'blue', label='AC')
plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
plt.title('Heat Transfer [W]')
plt.xlabel('Time Horizon (s)')

plt.figure(7)
plt.plot(D_time,D_TCE_L, label='Luminaire', color = 'orange')
plt.plot(D_time,D_TCE_AC, label='AC', color = 'blue')
plt.plot(D_time,D_TCE, label='Total', color = 'green')
plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
plt.title('Cumulative Energy [KWh]')
plt.xlabel('Time Horizon (s)')

plt.figure(8,figsize=(7,3.5*N))
for p in range(N):
    plt.subplot(N,2,2*p+1)
    plt.hist(D_LCmft[p],color ='orange')
    plt.title('Person %s Lumen Comfort' %str(p+1))
    plt.subplot(N,2,2*p+2)
    plt.hist(D_TCmft[p],color = 'blue')
    plt.title('Person %s Thermal Comfort' %str(p+1))
plt.tight_layout()

plt.figure(9)
plt.plot(D_time,D_TE_L, color = 'orange', label='Luminaire')
plt.plot(D_time,D_TE_AC, color = 'blue', label='AC')
plt.plot(D_time,D_TE, color = 'green', label='Total')
plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
plt.title('Energy Density [KWh]')
plt.xlabel('Time Horizon (s)')