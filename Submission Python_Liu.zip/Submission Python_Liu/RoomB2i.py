#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Mar  2 10:56:02 2018
@author: lixi
File 1
Room Type B: with luminaire-specific motion detectors
<<< with occupant feedback>>>
- High penalty fator (-10) if light turns off while occupants are still in the room
- After black-out, occupants move to trigger motion sensor
"""

#import matplotlib
#matplotlib.use('TkAgg')
import matplotlib.pyplot as PL
import pickle, os
import numpy.random as RD # RD.randint(a,b): b is exclusive
import numpy as NP
import scipy as SP
import math as M
RD.seed(1) # make seed constant
# x = true_value if condition else false_value

###############################################################################
                           ## Non-class functions ##
###############################################################################
def KtoF(TK):
    TF = TK*9/5.-459.67
    return TF          

def FtoK(TF):
    TK = (TF+459.67)*5/9.
    return TK

def update_temp():
    global time, DLHarv, HVACtrl, T, pT, odL, HTdl, HTaf, HTcd, HTac
    '''
    n = 2 # propagation depth
    dt = (1/float(d))**4/(4*n*(1/float(d))**2)
    ly,ry, lx,rx = min(RoomY)+1,max(RoomY)-1, min(RoomX)+1,max(RoomX)-1
    Temp[ly:ry, lx:rx] = preTemp[ly:ry, lx:rx] + dt * (
          (preTemp[ly+1:ry+1, lx:rx] - 2*preTemp[ly:ry, lx:rx] + preTemp[ly-1:ry-1, lx:rx])*(d**2)
          + (preTemp[ly:ry, lx+1:rx+1] - 2*preTemp[ly:ry, lx:rx] + preTemp[ly:ry, lx-1:rx-1])*(d**2))
    preTemp = Temp.copy()
    '''
    
    HTdl = DLHarv.HarvF*odHF*(SL/float(d)*wdW*wdN) # [w] heat transfer from harvested DL
    HTaf = VRair/3600.*Mair*Cpair*(FtoK(odT)-FtoK(pT)) #[w] heat transfer from ventilation
    # [w] heat transfer from building envelop losses (conduction through windows and wall)
    HTcd = ((float(rmX*rmH)-float(wdW*wdH*wdN))*Uwall+float(wdW*wdH*wdN)*Uwd)*(FtoK(odT)-FtoK(pT))
    # Qdot = (A_wall*U_wall + A_wdw*U_wdw)*deltT
    HTac = -Pwr_AC*HVACtrl.command # [w] heat transfer from AC
    
    T = KtoF(FtoK(pT) + (HTdl+HTaf+HTcd+HTac)/(Cpair*Mair))
    pT = T
    return T, pT

def calc_energy():
    global time, Lgt, DLHarv, HVACtrl, T, pT, odL,\
    TE_AC,TCE_AC, TE_L,TCE_L, TE,TCE
    
    # from lights
    TE_L = Lgt[0].Engy + Lgt[1].Engy    # [Wh] total energy from lighting - second level
    TCE_L = Lgt[0].CEngy + Lgt[1].CEngy # [Wh] total energy from lighting - cumulative
    
    # from AC
    TE_AC = Pwr_AC*HVACtrl.command/3600.#[Wh] energy from AC - second level
    TCE_AC += TE_AC                     #[Wh] energy from AC - cumulative

    # total
    TE = TE_L + TE_AC                   # [Wh] total energy - second level
    TCE = TCE_L + TCE_AC                # [Wh] total energy - cumulative

###############################################################################
                                ## Model Setup ##
###############################################################################
# define parameters
d = 10  # Interval in x or y direction                                
rmX, rmY, rmH = 5, 8, 3    # [m], room dim: length x by width y by height h
rmV = float(rmX*rmY*rmH)    # [m^3] room volume
gridX, gridY = (rmX+2)*d, (rmY+2)*d    # [m], Grid dim: x by y
## for display format:
Pms = 150*d/max(gridX,gridY)    # Markersize for occupants

# create wall and doorway (Line)
wallX = range(1*d,(rmX+1)*d+1)  # x range of wall length
wallY = range(1*d,(rmY+1)*d+1)  # y range of wall width
Uwall = 0.3 # [W/m^2K] net heat transfer coeff. of wall, roof: 0.15 W/m^2K (new building code)

doorX = [((rmX+1)/2)*d,((rmX+1)/2+1)*d]  # length along X direction, on South Wall
entryX = int(sum(doorX)/2.)   # x-pos before entering/leaving room
entryY = int(d/2.)            # y-pos before entering room
leaveY = entryY+d         # y-pos before leaving room

wdN = 2        # number of windows (max: 5)
wdH, wdW = 2, 1     # [m] height of window (wall height: 3m), [m] window width
Uwd = 1.1   # [W/m^2K] net heat transfer coeff. of windows
# new building code: 1.6 W/m2K
# Double insulated glazing 24 mm with argon filling: 1.1 W/m2K
# Triple insulated glazing 36 mm with argon filling: 0.7 W/m2K
# Triple insulated glazing 44 mm with argon filling: 0.6 W/m2K
# Triple insulated glazing 36 mm with krypton filling: 0.5 W/m2K

mspace = 0.5     # [m] minimum spacing between windows and wall
wdW = min(wdW,(rmX-mspace*(wdN+1))/wdN) # [m] window width s.t. upper bound 
Windows = {
        0: range(20,31),
        1: range(40,51)}
'''
Windows = {}
for i in range(wdN):
    space = (rmX-wdW*wdN)/(wdN+1)*d  #
    Le = min(wallX)
    Windows[i] = range(int(Le+(i+1)*space+i*wdW*d), int(Le+(i+1)*(space+wdW*d))+1)   
'''    
# Define Room (Patch)
RoomX = range(1*d,(1+rmX)*d+1)  # x range of Room length
RoomY = range(1*d,(1+rmY)*d+1)  # y range of Room width

# Desired Light and Temp Level
desLux =650.   # [lux]: lm/sq m
desT = 70.    # [deg F]

##### Daylight Data #####
angle = 40      # Elevation angle of the sun (from ground)
# Based on 03/27/18 daytime:
# Time:  8:00 09:00 10:00 11:00 12:00 13:00 14:00 15:00 16:00 17:00 18:00 19:00
# Angle: 6.09 17.01 27.54 37.09 44.83 49.56 50.14 46.39 39.30 30.12 19.79 8.93

SD = int((3-wdH)/M.tan(M.radians(angle))*d) # length of shadow of wall below window
SL = int(wdH/M.tan(M.radians(angle))*d)     # length of sunlight on room floor
odLY = range(max(wallY)-SD-SL,max(wallY)+1)     # range of length of sunlight on room floor

##### Temperature Data #####
odW = 177.5         # [W/m^2] avg solar insolation in Ann Arbor, 240 W/m^2 global avg?
sigma = 5.67E-8     # [W/(m^2*K^4)] Boltzman's constant
odHF = 480          # [W/m^2] heat flux from sun
odT = KtoF((odHF/sigma)**(1/4.))      # [F] outdoor temperature (85.73)

Dair = 101325/(287.05*FtoK(desT)) # [kg/m^3] = P/(RairT) (assumed at 1 atm, 70F)
Cpair = 1005 # [J/kgK] specific heat capacity of air at constant pressure [assumed at 70F]
Mair = rmV*Dair # [kg] mass of air for entire room
VRair = 1 # [1/hr] air change rate from ventilation (e.g. once an hour)
Pwr_AC = 8*rmV # [W] power rating of AC = [W/m^3]*V[m^3] = 1000W for 120 m^3

###############################################################################
                           ## Class Definition ##
###############################################################################
########################## <<< Class: Occupants >>> ###########################

class Occupant(object):
    p_y, p_x = entryY, entryX  # y-pos, x-pos: in front of door
    p_or = RD.randint(0,4)*90        # orientation: due North
    pp_y, pp_x, pp_or = p_y, p_x, p_or      # previous y-pos, x-pos, orientation
    LCmft, TCmft = 0, 0         # Lumen comfort, Thermal comfort = (actual-pref)/pref 
    
    def __init__(self,name,et,lt,LPref,TPref):
        self.name = name
        self.et = et            # time to enter room
        self.lt = lt            # time to leave room
        self.LPref = LPref      # Lumen preference [Lux]
        self.TPref = TPref      # Thermal preference [F]
        
    def randwalk(self):
        self.p_or = self.p_or%360
        if self.p_or == 0:               # filter for North
            if self.p_y+d < max(RoomY):        
                self.p_y += d           # step up 1
            else:
                self.p_y += -d           # fixed boundary, turn around & step 1
        elif self.p_or == 90:            # filter for East
            if self.p_x+d < max(RoomX):
                self.p_x += d           # step right 1
            else:
                self.p_x += -d           # fixed boundary, turn around & step 1
        elif self.p_or == 180:           # filter for South
            if self.p_y-d > min(RoomY):
                self.p_y += -d           # step down 1
            else:
                self.p_y += d           # fixed boundary, turn around & step 1
        else:                           # filter for West
            if self.p_x-d > min(RoomX):
                self.p_x += -d           # step left 1
            else:
                self.p_x += d           # fixed boundary, turn around & step 1
        self.p_or += RD.randint(-1,2)*90
    
    def move(self,et,lt):
        global time
        # record previous states:
        self.pp_x, self.pp_y, self.pp_or = self.p_x, self.p_y, self.p_or

        if time == et:    # at specified enter time
            self.p_y += d                  ### enter room
            self.p_or += RD.randint(-1,2)*90
        elif et< time <= et+10:     ### keeps moving for the first 10 seconds
            self.randwalk()
        elif et+5 < time < lt:
            # move to trigger motion sensor when room turns off(feedback)
            # OR 10% chance of random walk, else stay put
            if self.LCmft == -10 or RD.randint(0,10) > 8: #RD.randint(4,8):        
                self.randwalk()
        else:                               ### Leave Room
            if self.p_x - entryX > 0:
                self.p_x += -d
            elif self.p_x - entryX < 0:
                self.p_x += d
            elif self.p_y - leaveY >= 0:
                self.p_y += -d
    
    def update_comfort(self,LPref,TPref):
        global time, TotalLux, T
        if self.p_y != entryY or self.p_x != entryX:
            self.LCmft = (TotalLux[self.p_y,self.p_x]-self.LPref)/self.LPref
            self.LCmft = self.LCmft*10 if self.LCmft==-1 else self.LCmft # high penalty factor
            self.TCmft = (T-self.TPref)/self.TPref

        
########################## <<< Class: Sensors >>> #############################
class MSensor(object):  # sub-class: Motion Sensors
    state = 0       # current state: e.g. motion_detected?
    pstate = 0      # previous state
    command = 0     # power_on?
    timer = 0
    timerLim = 10    # limit on timer, i.e. power off after time limit
    
    def __init__(self,name):
        self.name = name
    
    def check_motion(self,L):
        global time, Ppl
        self.pstate = self.state    # record previous state: motion_detected?
        self.state = 0          # reset current motion_detected?
        
        for p in range(len(Ppl)):
            p_x = Ppl[p].p_x     # current x-pos of person
            p_y = Ppl[p].p_y     # current y-pos of person
            pp_x = Ppl[p].pp_x   # last x-pos of person
            pp_y = Ppl[p].pp_y   # last y-pos of person
            p2 = (p_x-L.p_x)**2 + (p_y-L.p_y)**2    # create circle at lamp loc.
            if p2 < (L.dia*d/2)**2:
                if abs(p_x-pp_x) > 0 or abs(p_y-pp_y) > 0:  # if movement is detected
                    self.state = 1       # set current motion_detected? true
                    self.command = 1     # turn power on
                    self.timer = 0          # reset motion timer
                    break

        if self.state == 0:        # if no motion is detected currently...
            if self.pstate == 1:         # but motion is detected previously
                self.timer += 1             # advance timer
            else:
                if 0 < self.timer < self.timerLim:     # if timer is started and within limit
                    self.timer += 1         # advance timer
                else:
                    self.command = 0   # turn power off
                    self.timer = 0     # reset motion timer


class TSensor(object): # sub-class: Thermal Sensors
    command = 0
    LT, HT = desT-2.5, desT+2.5 # [F] control temp: turn off AC at LT, turn on AC at HT
    def __init__(self,name):
        self.name = name
        
    def AC_on(self):
        global Mod, T, pT
        if T >= self.HT:
            self.command = 1
        elif T <= self.LT:
            self.command = 0
            
    
class DLSensor(object): # sub-class: DayLight (Harvesting) Sensors
    command = 0
    TInt = 5     # [s] update DLH reading every TInt number of ticks
    Timer = 0    # timer used to model interval DLH update
    HarvF, DLH = 0, 0   # DL harvesting factor: 0 <= HarvF <= 1, # [lux] amt of DL harvested
    
    def __init__(self,name):
        self.name = name
    
    def daylight_harvest(self,MD): # 
        global time, HarvLux, Temp, preTemp, odL
        self.Timer = self.Timer % self.TInt # reformat timer
        if MD.command == 1: # if motion is detected from the sensor closest to the windows
            if self.Timer == 0:      # update dimming at interval of TInt ticks
                self.HarvF = min(1, desLux/odL) # calculate harvesting factor based on desired lux, outdoor lux, and harvesting eff.
            self.Timer += 1          # advance time
        else:
            self.HarvF = 0    # close blinds when power off
            self.Timer = 0   # reset to initial condition
            
        ly,ry = min(odLY), max(odLY) #slicing with left bound (l) and right bound (r)
        lx0, rx0 = min(Windows[0]), max(Windows[0])
        lx1, rx1 = min(Windows[1]), max(Windows[1])
        self.DLH = self.HarvF*odL # [lux]
        HarvLux[ly:ry, lx0:rx0], HarvLux[ly:ry, lx1:rx1] = self.DLH, self.DLH

        
############################ <<< Class: Light >>> #############################
class Light(object): # Class of lights (include a dimmer per fixture)
    state = 0       # [lux] current lux level
    pstate = 0      # [lux] previous lux level
    maxLux = 900    # [lux] max lux output [lm/m^2]
    dia = min(rmX+1,rmY+1,10)   # [m] beam diameter
    dimF = 0.5      # dimming factor: 0.3 <= dimF <= 1
    dimTInt = 5     # [s] update dimmer reading every dimTInt number of ticks
    dimTimer = 3    # dimmer timer used to model interval dimming update
    clr = 'grey'    # color for display
    LLux = SP.zeros([gridY,gridX]) # Lamp Lux for each fixture
    Pwr = 60        # [w] power consumption
    Engy = 0        # [wh] sec-level energy consumption
    CEngy = 0       # [Wh] cumulative energy consumption
    
    def __init__(self,name,p_x,p_y):
        self.name = name
        self.p_x = p_x  # x-pos
        self.p_y = p_y  # y-pos
            
    def adjust_dimmer(self,MD):
        global time, HarvLux
        self.dimTimer = self.dimTimer % self.dimTInt # reformat timer
        
        if MD.command == 1: # if power_on is commanded...
            if self.dimTimer == 0:      # update dimming at interval of dimTInt ticks
                pd = self.dia/4*d    # lighting-sensing probe distance from lamp center
                HLux = (HarvLux[self.p_y,self.p_x]+HarvLux[self.p_y+pd,self.p_x]
                +HarvLux[self.p_y-pd,self.p_x]+HarvLux[self.p_y,self.p_x+pd]
                +HarvLux[self.p_y,self.p_x-pd])/float(5) # takes the average of 5 measurement pt
                
                dimN = (desLux-HLux)/float(self.maxLux)    # Dimming need based on daylight harvesting
                self.dimF = max(0.3,min(1,max(0,dimN)))    # determine dimming factor based on dimN
            
            self.dimTimer += 1          # advance timer
              
    def light_on(self,MD):
        global time
        self.pstate = self.state    # record previous state
        
        if MD.command == 1: # if power_on is commanded...
            self.state = self.maxLux*self.dimF # light on and dimmed to level
            self.clr = 'gold'
        else:
            self.state = 0  # light off
            self.dimTimer = 3   # reset to initial condition (3 allows for slight delay)
            self.dimF = 0.5
            self.clr = 'grey'
        
        self.LLux = SP.zeros([gridY,gridX])
        for x in RoomX:
            for y in RoomY:  
                p2 = (x-self.p_x)**2 + (y-self.p_y)**2    # create circle at lamp loc.
                if p2 < (self.dia*d/2)**2:
                    self.LLux[y,x] = self.state           # create circular light beam
                    
        # Light Spectral Diffusion - Propagate with central-difference in space(by i)
        n, i = 3, 5 # propagation depth, i: Propagation width
        dt = (1/float(d))**4/(4*n*(1/float(d))**2) # diffusion coeff. across space
        self.LLux[i:-i, i:-i] = self.LLux[i:-i, i:-i] + dt * (
          (self.LLux[2*i:, i:-i] - 2*self.LLux[i:-i, i:-i] + self.LLux[:-2*i, i:-i])*(d**2)
          + (self.LLux[i:-i, 2*i:] - 2*self.LLux[i:-i, i:-i] + self.LLux[i:-i, :-2*i])*(d**2))    
        
        
    def calc_energy(self):
        self.Engy = self.Pwr*(self.state/self.maxLux)/3600. #[Wh] Energy - second level
        self.CEngy += self.Engy              #[Wh] Energy - cumulative
        

###############################################################################
                           ## initialize function ##
###############################################################################
def init(N_Ppl):
    global time, max_time, Ppl, Lgt, Mod, HVACtrl, DLHarv,\
    HarvLux, LampLux, TotalLux, T, pT, odL,\
    HTdl, HTaf, HTcd, HTac, \
    TE_AC,TCE_AC, TE_L,TCE_L, TE, TCE, \
    D_time, D_odL, D_RmT, D_DLH, D_LCmft,D_TCmft, \
    D_MoSen0,D_PwrOn0, D_MoSen1,D_PwrOn1, D_LM0,D_DF0, D_LM1,D_DF1, \
    D_HTdl, D_HTaf, D_HTcd, D_HTac, \
    D_TE_L,D_TCE_L, D_TE_AC,D_TCE_AC, D_TE,D_TCE 

    time = 0
    odL = 10752.    # [lux] outdoor daylight (full day light)
    # overcast day = 1075, very dark day = 107
    
    HarvLux = SP.ones([gridY,gridX])*odL
    LampLux = SP.empty([gridY,gridX])
    
    T = 70
    pT = T
    
    ly,ry, lx,rx = min(RoomY),max(RoomY), min(RoomX),max(RoomX)
    HarvLux[ly:ry, lx:rx] = 0
    # LampLux[ly:ry,lx:rx] = 0    
    # preHarvLux = HarvLux.copy() # [lux]
    # preLampLux = LampLux.copy() # [lux]
    TotalLux = HarvLux + LampLux
    
    # Create light fixtures (includes dimming)
    L1 = Light('L1',sum(wallX)/len(wallX),sum(wallY)/len(wallY)*2/3) # (name,p_x,p_y)
    L2 = Light('L2',sum(wallX)/len(wallX),sum(wallY)/len(wallY)*4/3) # (name,p_x,p_y)
    Lgt = [L1,L2]   # set of light fixtures
    
    # Create lamp-specific motion sensors (agents)
    MD1 = MSensor('Motion Detector 1')   # (name)
    MD2 = MSensor('Motion Detector 2')   # (name)
    Mod = [MD1, MD2] # set of motion detectors
    
    # Create other sensors (agents)
    HVACtrl = TSensor('HVAC Controller')    # (name)
    DLHarv = DLSensor('Daylight Harvesting')   # (name)
    
    # Create people (agents)
    Ppl =[] # set of people
    for p in range(N_Ppl):
        # Lumen preference [500-800 lux]
        # Thermal preference [65-75 F]
        # (name,et,lt, \ lumen pref,thermal pref)
        Ppl.append (Occupant('P1', p+1, max_time-RD.randint(10,301), \
           RD.randint(500,801),RD.randint(65,76)))
    
    # Temp Ctrl-Heat Flux factors from: 
        # daylight (dl), air flow (af), building envelop losses (loss), AC
    HTdl, HTaf, HTcd, HTac = 0,0,0,0
    
    # Total Energy and Cumulative Energy from: AC, Light, and total
    TE_AC,TCE_AC, TE_L,TCE_L, TE,TCE = 0,0,0,0,0,0
    
    ###########################################################################
                         ## Data Structures for Output ##

    D_time, D_RmT, D_odL, D_DLH = [],[],[],[]           # time[s], # RmT [F], odL [lux], # Daylight Harvest []
    
    D_LCmft,D_TCmft = {},{}  # Occupant lumen comfort, # Occupant thermal comfort [perfect comfort = 0]
    
    D_MoSen0,D_PwrOn0, D_MoSen1,D_PwrOn1  = [],[],[],[] # Motion_detected? # Power_on?
    
    D_LM0,D_DF0, D_LM1,D_DF1 = [],[],[],[]              # Light lumen [lux], #Light dimming factor
    
    D_HTdl, D_HTaf, D_HTcd, D_HTac = [],[],[],[]        # heat transfers [W]
    
    D_TE_L, D_TCE_L = [],[]                             # second-level [KWh], #cumulative energy [KWh]
    D_TE_AC, D_TCE_AC = [],[]                           # second-level [KWh], #cumulative energy [KWh]
    D_TE, D_TCE = [],[]                                 # second-level [KWh], #cumulative energy [KWh]
    
    # Record Data
    D_time.append(time), D_odL.append(odL), D_RmT.append(T) #[s], #[lux], #[F]
    
    for p in range(len(Ppl)):
        D_LCmft[p],D_TCmft[p] = [],[]
        D_LCmft[p].append(Ppl[p].LCmft)
        D_TCmft[p].append(Ppl[p].TCmft) #[perfect comfort = 0]
    
    D_MoSen0.append(Mod[0].state), D_PwrOn0.append(Mod[0].command)
    D_MoSen1.append(Mod[1].state), D_PwrOn1.append(Mod[1].command)
    D_DLH.append(DLHarv.DLH) #[lux]

    D_LM0.append(Lgt[0].state), D_DF0.append(Lgt[0].dimF) #[lux], #[]
    D_LM1.append(Lgt[1].state), D_DF1.append(Lgt[1].dimF) #[lux], #[]
    
    D_HTdl.append(HTdl),        D_HTaf.append(HTaf) #[W], #[W]
    D_HTcd.append(HTcd),        D_HTac.append(HTac) #[W], #[W]
       
    D_TE_L.append(TE_L),        D_TCE_L.append(TCE_L)   #[KWh], #[KWh]
    D_TE_AC.append(TE_AC),      D_TCE_AC.append(TCE_AC) #[KWh], #[KWh]
    D_TE.append(TE),            D_TCE.append(TCE)       #[KWh], #[KWh]

###############################################################################
                               ## step function ##
###############################################################################
def step(opfile):
    global time, max_time, Ppl, Lgt, Mod, HVACtrl, DLHarv,\
    HarvLux, LampLux, TotalLux, T, pT, odL,\
    HTdl, HTaf, HTcd, HTac, \
    TE_AC,TCE_AC, TE_L,TCE_L, TE, TCE, \
    D_time, D_odL, D_RmT, D_DLH, D_LCmft,D_TCmft, \
    D_MoSen0,D_PwrOn0, D_MoSen1,D_PwrOn1, D_LM0,D_DF0, D_LM1,D_DF1, \
    D_HTdl, D_HTaf, D_HTcd, D_HTac, \
    D_TE_L,D_TCE_L, D_TE_AC,D_TCE_AC, D_TE,D_TCE 

    while time < max_time:
        time += 1
        odL = RD.normal(10750,1000) if RD.randint(0,5)>3 else odL # 20% chance of changing (by normal distribution)
        
        # class-specific functions
        for p in range(len(Ppl)):
            Ppl[p].move(Ppl[p].et,Ppl[p].lt) # move

        Mod[0].check_motion(Lgt[0])
        Mod[1].check_motion(Lgt[1])
        DLHarv.daylight_harvest(Mod[1]) # triggered only by motion sensor closest to windows
        Lgt[0].adjust_dimmer(Mod[0])
        Lgt[1].adjust_dimmer(Mod[1]) 
        Lgt[0].light_on(Mod[0]) # turn on light and update lux
        Lgt[1].light_on(Mod[1])
        
        LampLux = Lgt[0].LLux + Lgt[1].LLux
        TotalLux = HarvLux + LampLux
        HVACtrl.AC_on()
        
        update_temp()
        Lgt[0].calc_energy()
        Lgt[1].calc_energy()
        calc_energy()
        
        # update lumen and thermal comfort
        for p in range(len(Ppl)):
            Ppl[p].update_comfort(Ppl[p].LPref,Ppl[p].TPref) 
        
        # Record Data
        D_time.append(time), D_odL.append(odL), D_RmT.append(T) #[s], #[lux], #[F]
    
        for p in range(len(Ppl)):
            D_LCmft[p].append(Ppl[p].LCmft)
            D_TCmft[p].append(Ppl[p].TCmft) #[perfect comfort = 0]
        
        D_MoSen0.append(Mod[0].state), D_PwrOn0.append(Mod[0].command)
        D_MoSen1.append(Mod[1].state), D_PwrOn1.append(Mod[1].command)
        D_DLH.append(DLHarv.DLH) #[lux]
    
        D_LM0.append(Lgt[0].state), D_DF0.append(Lgt[0].dimF) #[lux], #[]
        D_LM1.append(Lgt[1].state), D_DF1.append(Lgt[1].dimF) #[lux], #[]
        
        D_HTdl.append(HTdl),        D_HTaf.append(HTaf) #[W], #[W]
        D_HTcd.append(HTcd),        D_HTac.append(HTac) #[W], #[W]
           
        D_TE_L.append(TE_L),        D_TCE_L.append(TCE_L)   #[KWh], #[KWh]
        D_TE_AC.append(TE_AC),      D_TCE_AC.append(TCE_AC) #[KWh], #[KWh]
        D_TE.append(TE),            D_TCE.append(TCE)       #[KWh], #[KWh]
        
    ###############################################################################
                               ## export pickle ##
    ###############################################################################
    output = open(opfile, 'wb')
    # file dumps (pickle protocol -> 0: ASCII code| 1:binary| -1: newest, more eff)
    pickle.dump(D_time, output, -1), pickle.dump(D_RmT, output, -1) #[S], #[F]]
    pickle.dump(D_odL, output, -1), pickle.dump(D_DLH, output, -1) #[lux], #[lux]
    
    ## Energy cal
    pickle.dump(D_TE_L, output, -1), pickle.dump(D_TCE_L, output, -1)   #[KWh], #[KWh]
    pickle.dump(D_TE_AC, output, -1), pickle.dump(D_TCE_AC, output, -1) #[KWh], #[KWh]
    pickle.dump(D_TE, output, -1), pickle.dump(D_TCE, output, -1)       #[KWh], #[KWh]
    
    ## Heat transfers
    pickle.dump(D_HTdl, output, -1), pickle.dump(D_HTaf, output, -1) #[W], #[W]
    pickle.dump(D_HTcd, output, -1), pickle.dump(D_HTac, output, -1) #[W], #[W] 
    
    ## Lights
    pickle.dump(D_MoSen0, output, -1), pickle.dump(D_PwrOn0, output, -1) #[]
    pickle.dump(D_MoSen1, output, -1), pickle.dump(D_PwrOn1, output, -1) #[]
    pickle.dump(D_LM0, output, -1), pickle.dump(D_DF0, output, -1) #[lux], #[]
    pickle.dump(D_LM1, output, -1), pickle.dump(D_DF1, output, -1) #[lux], #[]
    
    ## Occupants
    for p in range(len(Ppl)):
        pickle.dump(D_LCmft[p], output, -1)
        pickle.dump(D_TCmft[p], output, -1) #[perfect comfort = 0]
    
    output.close()

    return opfile, D_time, D_TCE_L, D_TCE_AC, D_TCE, D_LCmft, D_TCmft
###############################################################################
                        ## display function (draw) ##
###############################################################################
def draw():
#    PL.figure(1) # Lux Level
    PL.cla() # clear
    PL.pcolor(TotalLux, vmin = 0, vmax = 2000, cmap = PL.cm.afmhot) # or use cm.bwr #color according to states
    cb = PL.colorbar()
    cb.remove()
    cb = PL.colorbar()
    # Draw walls
    PL.plot(wallX,SP.ones(len(wallX))*d,linewidth=5,color='darkgreen')                # Wall-South
    PL.plot(wallX,SP.ones(len(wallX))*max(wallY),linewidth=5,color='darkgreen')     # Wall-North
    PL.plot(SP.ones(len(wallY))*d,wallY,linewidth=5,color='darkgreen')                # Wall-West
    PL.plot(SP.ones(len(wallY))*max(wallX),wallY,linewidth=5,color='darkgreen')     # Wall-East
    # Draw door
    PL.plot(doorX,SP.ones(len(doorX))*d,linewidth=5,color='white')
    # Draw window
    PL.plot(Windows[0],SP.ones(len(Windows[0]))*max(wallY),linewidth=2,linestyle=':',color='white')  # North facing
    PL.plot(Windows[1],SP.ones(len(Windows[1]))*max(wallY),linewidth=2,linestyle=':',color='white')  # North facing
    # Plot Light location
    PL.plot(Lgt[0].p_x,Lgt[0].p_y, marker='.', markersize=200*d/gridY, color=Lgt[0].clr)    # light loc
    PL.plot(Lgt[1].p_x,Lgt[1].p_y, marker='.', markersize=200*d/gridY, color=Lgt[1].clr)    # light loc
    # Plot persons
    for p in range(len(Ppl)):
        PL.plot(Ppl[p].p_x,Ppl[0].p_y, marker='s',markersize=Pms)

    # Other Setting
    PL.axis('image')
    PL.title('Illuminance [lux]\n' +\
             't = %s | T = %s F' %(str(time),round(T,1)))
    PL.xticks(NP.arange(0, gridX, d))
    PL.yticks(NP.arange(0, gridY, d))
    PL.grid() # grid on


###############################################################################
                                ## Control Panel ##
###############################################################################
# use > os.getcwd() < to get current directory
model_name = 'RB2i'
max_time = 3600+20 # 1hr
N = 3       # number of occupants
Nsam = 100  # number of samples for Monte Carlos
mode = 2 
# 0: normal simulation (1 time)
# 1: parameter sweep over N
# 2: Monte Carlos

if mode == 0: ### normal simulation ###
    N_Ppl = N
    opfile = '%s_data_%s_%s' %(model_name,str(N_Ppl),str(max_time))
    init(N_Ppl)
    # draw()
    step(opfile) # use downloadBi.py and plotBi.py to plot results <====
    
elif mode == 1: ### parameter sweep ####
    EngyL, EngyAC, Engy, LC, TC = [],[],[],[],[]
    
    def parasweep(N):
    # parameter sweep across occupants
        for N_Ppl in range(1,N+1):
            opfile = '%s_data_%s_%s' %(model_name,str(N_Ppl),str(max_time))
            init(N_Ppl)
            #draw()
            step(opfile)
            # compile output
            EngyL.append(D_TCE_L), EngyAC.append(D_TCE_AC), Engy.append(D_TCE)
            LC.append(D_LCmft), TC.append(D_TCmft)
        
        return EngyL, EngyAC, Engy, LC, TC
    
    parasweep(N) # use Psweep_plot.py to plot results <====
    
    # pickle parameter sweep output
    psfile = '%s_psweep_1-%s_%s' %(model_name,str(N),str(max_time))
    output = open(psfile, 'wb')
    # file dumps (pickle protocol -> 0: ASCII code| 1:binary| -1: newest, more eff)
    pickle.dump(D_time, output, -1), pickle.dump(EngyL, output, -1)
    pickle.dump(EngyAC, output, -1), pickle.dump(Engy, output, -1)
    pickle.dump(LC, output, -1),     pickle.dump(TC, output, -1)
    output.close()
    
else:
    EngyL, EngyAC, Engy, LC, TC = [],[],[],[],[]
    
    def montecarlos(Nsam):
    # parameter sweep across occupants
        for i in range(Nsam):
            opfile = 'MC_%s_data_%s_%s' %(model_name,str(i),str(max_time))
            init(N)
            Mod[0].timerLim = RD.randint(5,31)
            Mod[1].timerLim = RD.randint(5,31)
            # + each occupant has 10-50% chance of random walk (line 201)
            #draw()
            step(opfile)
            # compile output
            EngyL.append(D_TCE_L), EngyAC.append(D_TCE_AC), Engy.append(D_TCE)
            LC.append(D_LCmft), TC.append(D_TCmft)
            print 'Simulation %s done.' %str(i)
            
        return EngyL, EngyAC, Engy, LC, TC
    
    montecarlos(Nsam) # use Psweep_plot.py to plot results <====
    
    # pickle parameter sweep output
    psfile = 'MC_%s_%s_1-%s_%s' %(model_name,str(N),str(Nsam),str(max_time))
    output = open(psfile, 'wb')
    # file dumps (pickle protocol -> 0: ASCII code| 1:binary| -1: newest, more eff)
    pickle.dump(D_time, output, -1), pickle.dump(EngyL, output, -1)
    pickle.dump(EngyAC, output, -1), pickle.dump(Engy, output, -1)
    pickle.dump(LC, output, -1),     pickle.dump(TC, output, -1)
    output.close()
    
print'Simulation completed'
