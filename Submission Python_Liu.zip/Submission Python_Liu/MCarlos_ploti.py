#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 24 02:04:08 2018
@author: lixi
For plotting Monte Carlos results
"""

import matplotlib.pyplot as plt
import array

plt.figure()
for n in range(Nsam):
    plt.plot(D_time, EngyL[n], label='N=%s' %str(n))
plt.title('Cumulative Energy from Luminaires [kWh]')
plt.xlabel('Time Horizon (s)')
#plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)

plt.figure()
for n in range(Nsam):
    plt.plot(D_time, EngyAC[n], label='N=%s' %str(n))
plt.title('Cumulative Energy from AC [kWh]')
plt.xlabel('Time Horizon (s)')
#plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)

plt.figure()
for n in range(Nsam):
    plt.plot(D_time, Engy[n], label='N=%s' %str(n))
plt.title('Total Cumulative Energy [kWh]')
plt.xlabel('Time Horizon (s)')
#plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)

count = []
for n in range(Nsam):
    ct = 0
    for p in range(len(LC[n])):
        for t in range(len(D_time)):
            if LC[n][p][t] < -5:
                ct += 1
    ct = ct/float(len(LC[n]))
    count.append(ct)
plt.figure()
plt.scatter(range(Nsam),count, marker = 'o')
plt.title('Average Per Person Count of Room Blackouts')
plt.xlabel('Sample Run No.')

avgLC, avgTC = [],[]
for n in range(Nsam):
    sumLC, sumTC = [],[]
    for p in range(len(LC[n])):
        sumLC.append([x**2 for x in LC[n][p]]) # add together the squared values of each person
        sumTC.append([x**2 for x in TC[n][p]]) # add together the squared values of each person
        avgLC.append([(x/float(len(LC[n])))**0.5 for x in sumLC[p]]) # take avg of the squared value and sqrt
        avgTC.append([(x/float(len(TC[n])))**0.5 for x in sumTC[p]]) # take avg of the squared value and sqrt

avgLCV, avgTCV = [],[]
for n in range(Nsam):
    avgLCV.append(sum(avgLC[n])/float(len(D_time)))
    avgTCV.append(sum(avgTC[n])/float(len(D_time)))

plt.figure(figsize=(7,7))
plt.subplot(2,1,1)
plt.scatter(range(Nsam),avgLCV, marker = 'o')
plt.title('Average Per Person Lumen Comfort')
plt.xlabel('Sample Run No.')
plt.subplot(2,1,2)
plt.scatter(range(Nsam),avgTCV, marker = 'o')
plt.title('Average Per Person Thermal Comfort') 
plt.tight_layout()
plt.xlabel('Sample Run No.')

'''
plt.figure(figsize=(7,2*Nsam))
for n in range(Nsam):
    plt.subplot(Nsam,2,2*n+1)
    plt.hist(avgLC[n],color ='orange')
    plt.title('Average Lumen Comfort, N = %s' %str(n+1))
    plt.subplot(Nsam,2,2*n+2)
    plt.hist(avgTC[n],color = 'blue')
    plt.title('Average Thermal Comfort, N = %s' %str(n+1))
plt.tight_layout()
'''