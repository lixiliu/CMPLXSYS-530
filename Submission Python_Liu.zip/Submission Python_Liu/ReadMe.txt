##### Run -> download -> plot

1. Run Model Files (w/ pickle exports)
RoomA2: w/ a single room-based motion sensor
   # RoomA2_pycx.py: pycx version (does not have download or plot files)
   # RoomA2i.py: normal script, efficient for running large-scale results, has user controls for 1) normal run, 2) parameter sweep, and 3) Monte Carlos

RoomB2: w/ luminaire-based motion sensors
   # RoomB2_pycx.py: pycx version (does not have download or plot files)
   # RoomB2i.py: normal script, efficient for running large-scale results, has user controls for 1) normal run, 2) parameter sweep, and 3) Monte Carlos

#####
2. Download Pickles Files
   # downloadAi: for RoomA2i.py normal run only
   # downloadBi: for RoomB2i.py normal run only
   # MCPS_downloadi: for use with parameter sweep or Monte Carlos runs on RoomA2i or RoomB2i

#####
3. Plot Files
   # plotAi: for RoomA2i.py normal run only
   # plotBi: for RoomB2i.py normal run only
   # Psweep_ploti: for use with parameter sweep on RoomA2i or RoomB2i
   # MCarlos_ploti: for use with Monte Carlos on RoomA2i or RoomB2i